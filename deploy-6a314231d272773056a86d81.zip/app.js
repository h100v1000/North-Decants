const loadingEl = document.getElementById("loading");
const container = document.getElementById("products");
const toast = document.getElementById("cart-toast");

let toastTimeout;

function showToast(message) {
  toast.textContent = message;
  toast.removeAttribute("hidden");
  toast.classList.add("show");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.setAttribute("hidden", ""), 400);
  }, 2200);
}

function renderProduct(product, index) {
  const notes = product.notes.split(", ").map((n) => `<span class="note-tag">${n}</span>`).join("");

  const div = document.createElement("div");
  div.className = "product";
  div.innerHTML = `
    <p class="product-number">N° ${String(index + 1).padStart(2, "0")}</p>
    <h3>${product.name}</h3>
    <p class="product-description">${product.description || ""}</p>
    <div class="product-notes">${notes}</div>
    <div class="product-footer">
      <p class="product-price">€${product.price}<span>/ set</span></p>
      <button data-id="${product.id}" data-name="${product.name}">Add to cart</button>
    </div>
  `;

  div.querySelector("button").addEventListener("click", (e) => {
    const name = e.currentTarget.dataset.name;
    showToast(`${name} added`);
  });

  return div;
}

fetch("/api/products")
  .then((res) => {
    if (!res.ok) throw new Error("Failed to load products");
    return res.json();
  })
  .then((data) => {
    loadingEl.style.display = "none";
    data.forEach((product, i) => {
      container.appendChild(renderProduct(product, i));
    });
  })
  .catch((err) => {
    loadingEl.innerHTML = `<span style="color:#c0392b">Could not load products. Please try again.</span>`;
    console.error(err);
  });
